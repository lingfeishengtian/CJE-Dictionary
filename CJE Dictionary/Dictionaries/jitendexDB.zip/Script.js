function convertElementToRubyMarkdown(mainElem) {
    var str = ""
    for (let elem of mainElem.childNodes) {
        console.log(elem)
        if (elem.tagName == "RUBY") {
            let word = elem.childNodes[0].textContent
            let furigana = elem.childNodes[1].textContent
            str += `^[${word}](CTRubyAnnotation: '${furigana}')`
        } else {
            str += elem.textContent
        }
    }
    return str
}

function convertToJSON() {
    let senseGroups = document.querySelectorAll(".sense-group");
    var finalDefinitionGroups = []

    senseGroups.forEach(senseGroup => {
        let tag = senseGroup.querySelectorAll(".tag")
        var tags = []
        var definitions = []

        tag.forEach(tag => {
            tags.push({
                shortName: tag.getAttribute("data-code"),
                longName: tag.getAttribute("title")
            })
        })

        let senses = senseGroup.querySelectorAll(".sense")
        senses.forEach(sense => {
            let glossary = sense.querySelectorAll(".glossary li")
            var definition = []
            glossary.forEach(gloss => {
                definition.push(gloss.innerText)
            })
            definition = definition.join(", ")

            let extraInfoChildren = sense.querySelector(".extra-info")
            var exampleSentences = []
            
            if (extraInfoChildren == null) {
                definitions.push({
                    definition: definition,
                    exampleSentences: exampleSentences
                })
                return
            }

            for (let extraInfoChil of extraInfoChildren.children) {
                // If sentences
                if (extraInfoChil.classList.contains("example-container")) {
                    let exampleSentencesChildren = extraInfoChil.children
                    for (let exampleSentencesChild of exampleSentencesChildren) {
                        let exSentJa = exampleSentencesChild.querySelector(".ex-sent-ja-content")
                        let exSentEn = exampleSentencesChild.querySelector(".ex-sent-en-content")

                        let ja = convertElementToRubyMarkdown(exSentJa)
                        let en = convertElementToRubyMarkdown(exSentEn)

                        exampleSentences.push({
                            language: "ja",
                            sentence: ja
                        })
                        exampleSentences.push({
                            language: "en",
                            sentence: en
                        })
                    }
                } else {
                    // If sense notes
                    let senseNote = extraInfoChil.querySelector(".sense-note-content")
                    if (senseNote == null) {
                        continue
                    }
                    exampleSentences.push({
                        language: null,
                        sentence: senseNote.innerText
                    })
                }
            }

            definitions.push({
                definition: definition,
                exampleSentences: exampleSentences
            })
        });

        finalDefinitionGroups.push({
            tags: tags,
            definitions: definitions
        })
    });
    return finalDefinitionGroups
}

JSON.stringify(convertToJSON())
