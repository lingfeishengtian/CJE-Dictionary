function convertToJSON() {
    let ps = document.querySelectorAll("body > section > p");
    var finalDefinitionGroups = []

    var currentDefinitionGroup = {
        tags: [],
        definitions: []
    }
    for (let p of ps) {
        let dataOrgtag = p.getAttribute("data-orgtag")
        let level = p.getAttribute("level")

        if (dataOrgtag === "meaning" && level === "1") {
            if (currentDefinitionGroup.tags.length > 0 || currentDefinitionGroup.definitions.length > 0) {
                finalDefinitionGroups.push(currentDefinitionGroup)
                currentDefinitionGroup = {
                    tags: [],
                    definitions: []
                }
            }
            console.log(p.outerHTML)
            let secondSpan = p.children[1]
            currentDefinitionGroup.tags.push({
                shortName: secondSpan.getAttribute("type"),
                longName: secondSpan.innerText
            })
        }

        if (dataOrgtag === "meaning") {
            p.childNodes[0].remove()
            currentDefinitionGroup.definitions.push({
                definition: p.innerText,
                exampleSentences: []
            })
        }

        if (dataOrgtag === "example") {
            let exampleSentences = currentDefinitionGroup.definitions[currentDefinitionGroup.definitions.length - 1].exampleSentences
            let jae = p.querySelector("jae")
            let ja_cn = p.querySelector("ja_cn")

            exampleSentences.push({
                language: "ja",
                sentence: jae.innerText
            })

            exampleSentences.push({
                language: "cn",
                sentence: ja_cn.innerText
            })
        }      
    }

    finalDefinitionGroups.push(currentDefinitionGroup)  

    return finalDefinitionGroups
}

JSON.stringify(convertToJSON())
