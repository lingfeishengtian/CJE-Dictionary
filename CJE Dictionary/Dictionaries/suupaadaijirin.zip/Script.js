function convertToJSON() {
    let ps = document.querySelectorAll("he > a");
    var finalDefinitionGroups = []

    var tag = ""
    for (let a of document.querySelector("he").childNodes) {
        if (a.tagName == "A") {
            break
        }
        tag += a.textContent
        if (a.tagName == "SMALL") {
            break
        }
    }

    var currentDefinitionGroup = {
        tags: [],
        definitions: []
    }

    if (tag.length > 0) {
        currentDefinitionGroup.tags.push({
            shortName: "",
            longName: tag
        })
    }

    for (let p of ps) {
        let k = p.querySelector("k")
        if (k == null) {
            currentDefinitionGroup.definitions.push({
                definition: p.textContent,
                exampleSentences: []
            })
        } else {
            let currentDefinition = currentDefinitionGroup.definitions[currentDefinitionGroup.definitions.length - 1]
            currentDefinition.exampleSentences.push({
                language: "ja",
                sentence: k.textContent
            })
        }
    }

    finalDefinitionGroups.push(currentDefinitionGroup)

    return finalDefinitionGroups
}

JSON.stringify(convertToJSON())