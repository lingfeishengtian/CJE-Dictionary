function convertElementToRubyMarkdown(mainElem) {
    var str = ""
    for (let elem of mainElem.childNodes) {
        console.log(elem)
        if (elem.tagName == "NH") {
            let furigana = elem.textContent
            let last = str.substring(str.length - 1)
            str = str.slice(0, -1);
            str += `^[${last}](CTRubyAnnotation: '${furigana}')`
        } else {
            str += elem.textContent
        }
    }
    return str
}

function convertToJSON() {
    let ps = document.querySelectorAll("he > a");
    var finalDefinitionGroups = []

    var tag = ""
    for (let a of document.querySelector("he").childNodes) {
        if (a.tagName == "A" || (a.tagName == "V" && a.hasAttribute("v") && a.getAttribute("v").includes("丸"))) {
            break
        }
        tag += a.textContent
    }

    var currentDefinitionGroup = {
        tags: [],
        definitions: []
    }

    if (tag.length > 0) {
        currentDefinitionGroup.tags.push({
            shortName: "",
            longName: tag
        })
    }

    for (let p of ps) {
        let k = p.querySelector("k")
        if (k == null) {
            currentDefinitionGroup.definitions.push({
                definition: p.textContent,
                exampleSentences: []
            })
        } else {
            let currentDefinition = currentDefinitionGroup.definitions[currentDefinitionGroup.definitions.length - 1]
            currentDefinition.exampleSentences.push({
                language: "ja",
                sentence: convertElementToRubyMarkdown(k)
            })
        }
    }

    finalDefinitionGroups.push(currentDefinitionGroup)

    return finalDefinitionGroups
}

JSON.stringify(convertToJSON())